Wtyczka "Hexitor" dla Far Manager 3.0
*************************************

Edytor szesnastkowy dla Far Manager.

Instalacja:
  Rozpakowa� archiwum do folderu wtyczek w Far (...Far\Plugins).

Uwaga:
  Wtyczka jest udost�pniana "jak jest" (bez gwarancji). Autor nie odpowiada
  za konsekwencje wynikaj�ce z u�ywania tego programu.

Artem Senichev (artemsen@gmail.com)
               https://sourceforge.net/projects/farplugs/
